var myGamePiece;
var myBackground;
var myObstacles = [];
var myScore;
var mySound;
var myMusic;
var myTurbo;
var myJump;
var myDrop;


function startGame() {
    myScore = new componentScore("30px", "Consolas", "black", 575, 30, "text");
    myGamePiece = new component(131, 114, "img/smiley.gif", 15, 120, "image");
    
    // crash sound effect
    mySound = new sound("sounds/explosion.wav");

    // theme music
    myMusic = new sound("sounds/music.wav");

    // speed up right sound effect
    myTurbo = new sound("sounds/pikachu.wav");

    // go down sound effect
    myJump = new sound("sounds/bounce.mp3");

    // go down sound effect
    myDrop = new sound("sounds/SLDWSTdown.wav")

    // scrolling background 
    myBackground = new component(1280, 720, "img/cityMarket_1024.jpg", 0, 0, "background");

    // start the whole game
    myGameArea.start();

    // keyboard event controls initialize
    document.onkeydown = checkKey;
    document.onkeyup = checkKeyUp;
}

var myGameArea = {
    canvas : document.createElement("canvas"),
    start : function() {
        this.canvas.width = 1024;
        this.canvas.height = 576;

        // this._scale = this.width / 1920;
        // if (this._scale * 1080 <this.height) {
        //     this._scale = this.height / 1080;
        // }

        this.context = this.canvas.getContext("2d");
        document.body.append(this.canvas, document.body.childNodes[1]);
        this.frameNo = 0;
        this.interval = setInterval(updateGameArea, 10);
        },
    clear : function() {
        this.context.clearRect(0, 0, this.canvas.width, this.canvas.height);
    },
    stop : function() {
        clearInterval(this.interval);
    }
    // pause : function() {
        
    // }
}

function componentScore(width, height, color, x, y, type) {
    this.type = type;
    if (type == "image") {
    this.image = new Image();
    this.image.src = color;
  }
    this.width = width;
    this.height = height;
    this.speedX = 0;
    this.speedY = 0;
    this.x = x;
    this.y = y;
    this.update = function() {
        ctx = myGameArea.context;
        if (this.type == "text") {
            ctx.font = this.width + " " + this.height;
            ctx.fillStyle = color;
            ctx.fillText(this.text, this.x, this.y);
        } else {

            ctx.fillStyle = color;
            ctx.fillRect(this.x, this.y, this.width, this.height);
        }
    }
    
}

function component(width, height, color, x, y, type) {
    this.type = type;
    if (type == "image" || type == "background") {
        this.image = new Image();
        this.image.src = color;
    }
    this.width = width;
    this.height = height;
    this.speedX = 0;
    this.speedY = 0;    
    this.x = x;
    this.y = y;    
    this.update = function() {
        ctx = myGameArea.context;
        
        // this explicitly draws the game player and background
        if (type == "image" || type == "background") {
            ctx.drawImage(this.image, 
                this.x, 
                this.y,
                this.width, this.height);
                
        // this helps explicitly redraw the scrolling background between loops 
        if (type == "background") {
            ctx.drawImage(this.image, 
                this.x + this.width, 
                this.y,
                this.width, this.height);
        }
        } else {
            ctx.fillStyle = color;
            ctx.fillRect(this.x, this.y, this.width, this.height);
        }
        
    }
    this.newPos = function() {
        this.x += this.speedX;
        this.y += this.speedY;
        if (this.type == "background") {
            if (this.x == -(this.width)) {
                this.x = 0;
            }
        }
    }
    this.crashWith = function(otherobj) {
        var myleft = this.x;
        var myright = this.x + (this.width);
        var mytop = this.y;
        var mybottom = this.y + (this.height);
        var otherleft = otherobj.x;
        var otherright = otherobj.x + (otherobj.width);
        var othertop = otherobj.y;
        var otherbottom = otherobj.y + (otherobj.height);
        var crash = true;
        if ((mybottom <= othertop) || (mytop >= otherbottom) || (myright <= otherleft) || (myleft >= otherright)) {
            crash = false;
        }
        return crash;
    }    
}

function updateGameArea() {
    var x, height, gap, minHeight, maxHeight, minGap, maxGap;
    for (i = 0; i < myObstacles.length; i += 1) {
        
        myMusic.play();
        
        if (myGamePiece.crashWith(myObstacles[i])) {
            myMusic.stop();
            mySound.play();
            myGameArea.stop();
            return;
        }

        
    }
    myGameArea.clear();
    myBackground.speedX = -1;
    myBackground.newPos();    
    myBackground.update();

    myGameArea.frameNo += 1;
    if (myGameArea.frameNo == 1 || everyinterval(175)) {
        x = myGameArea.canvas.width;
        minHeight = 30;
        maxHeight = 250;
        height = Math.floor(Math.random()*(maxHeight-minHeight+1)+minHeight);
        minGap = 150;
        maxGap = 375;
        gap = Math.floor(Math.random()*(maxGap-minGap+1)+minGap);
        myObstacles.push(new component(22, height, "red", x, 0));
        myObstacles.push(new component(22, x - height - gap, "red", x, height + gap));
    }
    for (i = 0; i < myObstacles.length; i += 1) {
        myObstacles[i].speedX = -1;
        myObstacles[i].newPos();
        myObstacles[i].update();
    }
    
    myGamePiece.newPos();    
    myGamePiece.update();

    myScore.text="SCORE: " + myGameArea.frameNo;
    myScore.update();

    // if(myGameArea.frameNo > 500) {myGameArea.interval = setInterval(updateGameArea, 15)};
    // if(myGameArea.frameNo > 7000) {myGameArea.interval = setInterval(20)};
    // if(myGameArea.frameNo > 10000) {myGameArea.interval = setInterval(25)};

}



function everyinterval(n) {
    if ((myGameArea.frameNo / n) % 1 == 0) {return true;}
    return false;
}

function move(dir) {
    if (dir == "up") {myGamePiece.speedY = -1; myJump.play();}
    if (dir == "down") {myGamePiece.speedY = 1; myDrop.play();}
    if (dir == "right") {myGamePiece.speedX = 1; myTurbo.play();}
    if (dir == "left") {myGamePiece.speedX = -1; myGamePiece.image.src = "img/smiley_left.gif";}
        
}

function checkKey(e) {
    e = e || window.event;

    if (e.keyCode == '38') {
        // up arrow
        {myGamePiece.speedY = -3; }
        myJump.play();
    }
    else if (e.keyCode == '40') {
        // down arrow
        {myGamePiece.speedY = 3; }
        myDrop.play();
    }
    else if (e.keyCode == '37') {
       // left arrow
       {myGamePiece.speedX = -3; myGamePiece.image.src = "img/smiley_left.gif";}
    }
    else if (e.keyCode == '39') {
       // right arrow
       {myGamePiece.speedX = 3; myGamePiece.image.src = "img/smiley.gif"}
       myTurbo.play();
    }
    else if (e.keyCode == '32') {
       // space bar
       {myGamePiece.image.src = "img/smiley_flip.gif"}
    }
    else if (e.keyCode == '27') {
       // escape key
       {myGamePiece.speedX = 0}
       {myGamePiece.width = 87}
       {myGamePiece.height = 76}
       {myGamePiece.image.src = "img/smiley_shrink.gif"}
    }
    else if (e.keyCode == '19') {
       // right arrow
       myGameArea.stop();
    }
}

function checkKeyUp(e) {
    e = e || window.event;

    if (e.keyCode == '38') {
        // up arrow
        clearmove()
    }
    else if (e.keyCode == '40') {
        // down arrow
        clearmove()
    }
    else if (e.keyCode == '37') {
       // left arrow
       clearmove()
       //{myGamePiece.speedX = 0; myGamePiece.image.src = "smiley_left.gif";}
       myGamePiece = clampGamePiece(myGamePiece, 0, myGameArea.width - myGamePiece.width);
    }
    else if (e.keyCode == '39') {
       // right arrow
       clearmove()
       {myGamePiece.speedX = 0; myGamePiece.image.src = "img/smiley.gif"}
    }
    else if (e.keyCode == '32') {
       // space bar
       {myGamePiece.image.src = "img/smiley.gif"}
    }
    else if (e.keyCode == '27') {
       // escape key
       {myGamePiece.width = 131}
       {myGamePiece.height = 114}
       {myGamePiece.image.src = "img/smiley.gif"}
    }
    else if (e.keyCode == '19') {
       // right arrow
       myGameArea.start();
    } 
}

function clampGamePiece(x, min, max) {
    return x < min? min : (x > max ? max :x);
}

function clearmove() {
    myGamePiece.image.src = "img/smiley.gif";
    myGamePiece.speedX = 0; 
    myGamePiece.speedY = 0; 
}

function sound(src) {
    this.sound = document.createElement("audio");
    this.sound.src = src;
    this.sound.setAttribute("preload", "auto");
    this.sound.setAttribute("controls", "mute");
    this.sound.style.display = "none";
    document.body.appendChild(this.sound);
    this.play = function(){
        this.sound.play();
    }
    this.stop = function(){
        this.sound.pause();
    }
}
